# Evidências — Execução e Validação

Este documento registra o passo a passo da execução do ambiente Docker, a conexão com o PgAdmin e a execução do script SQL, além de servir como guia para as evidências visuais (prints) a serem anexados.

---

## 1. Pré-requisitos

- Docker Desktop instalado e em execução.
- Docker Compose disponível no terminal (`docker compose version`).
- Porta `5432` e `8080` livres na máquina local.

---

## 2. Subindo o ambiente

```bash
# Navegar até a pasta de infraestrutura
cd infra

# Subir os contêineres em segundo plano
docker compose up -d

# Verificar se os contêineres estão em execução
docker ps
```

**Resultado esperado do `docker ps`:**

```
CONTAINER ID   IMAGE            COMMAND                  STATUS         PORTS
xxxxxxxxxxxx   postgres         "docker-entrypoint.s…"   Up X seconds   0.0.0.0:5432->5432/tcp
xxxxxxxxxxxx   dpage/pgadmin4   "/entrypoint.sh"          Up X seconds   0.0.0.0:8080->80/tcp
```

> 📸 **Evidência 1:** print do terminal com o resultado do `docker ps` mostrando os dois contêineres ativos.

---

## 3. Acessando o PgAdmin

1. Abrir o navegador e acessar: **http://localhost:8080**
2. Fazer login com:
   - **E-mail:** `dssouzadan@gmail.com`
   - **Senha:** `teste`

> 📸 **Evidência 2:** print da tela de login do PgAdmin com as credenciais preenchidas.

---

## 4. Registrando o servidor PostgreSQL no PgAdmin

1. No painel esquerdo, clicar com o botão direito em **Servers → Register → Server...**
2. Na aba **General**, preencher:
   - **Name:** `postgres-local` (ou qualquer nome)
3. Na aba **Connection**, preencher:
   - **Host name/address:** `postgres`
   - **Port:** `5432`
   - **Username:** `postgres`
   - **Password:** `teste`
4. Clicar em **Save**.

> ⚠️ O host deve ser `postgres` (nome do serviço no Docker Compose), não `localhost`.

> 📸 **Evidência 3:** print da tela de configuração de conexão no PgAdmin.

---

## 5. Criando o banco de dados

1. No painel esquerdo, expandir o servidor registrado.
2. Clicar com o botão direito em **Databases → Create → Database...**
3. Preencher:
   - **Database:** `reserva_salas`
4. Clicar em **Save**.

> 📸 **Evidência 4:** print do banco `reserva_salas` criado e visível no painel esquerdo.

---

## 6. Executando o script SQL

1. Com o banco `reserva_salas` selecionado, abrir o **Query Tool** (ícone de banco de dados com raio).
2. Colar o conteúdo do arquivo `03_modelo_relacional.sql`.
3. Clicar em **Execute** (tecla F5 ou botão ▶).

> 📸 **Evidência 5:** print do Query Tool com o script colado e o resultado da execução sem erros.

---

## 7. Verificando as tabelas e dados

Após executar o script, verificar no painel esquerdo:

```
reserva_salas
  └── Schemas
        └── public
              └── Tables
                    ├── reserva
                    ├── sala
                    └── solicitante
```

Para confirmar os dados inseridos, executar no Query Tool:

```sql
SELECT
    r.id             AS reserva_id,
    s.nome           AS sala,
    sl.nome          AS solicitante,
    r.data,
    r.hora_inicio,
    r.hora_fim,
    r.situacao
FROM reserva r
JOIN sala        s  ON s.id  = r.sala_id
JOIN solicitante sl ON sl.id = r.solicitante_id
ORDER BY r.data, r.hora_inicio;
```

**Resultado esperado:**

| reserva_id | sala    | solicitante   | data       | hora_inicio | hora_fim | situacao  |
|------------|---------|---------------|------------|-------------|----------|-----------|
| 1          | Sala A1 | Ana Souza     | 2025-08-04 | 08:00       | 10:00    | ativa     |
| 2          | Sala B2 | Bruno Lima    | 2025-08-04 | 14:00       | 16:00    | ativa     |
| 3          | Sala A1 | Carla Mendes  | 2025-08-05 | 09:00       | 11:00    | cancelada |
| 4          | Sala C3 | Ana Souza     | 2025-08-06 | 10:00       | 12:00    | ativa     |

> 📸 **Evidência 6:** print do resultado da consulta JOIN no Query Tool do PgAdmin.

---

## 8. Encerrando o ambiente

```bash
# Parar e remover os contêineres
docker compose down

# Para remover também os dados persistidos (volume local):
# docker compose down -v
```

---

## Checklist de evidências

- [ ] Print 1 — Terminal com `docker ps` (dois contêineres ativos)
- [ ] Print 2 — Tela de login do PgAdmin
- [ ] Print 3 — Tela de conexão ao servidor PostgreSQL
- [ ] Print 4 — Banco `reserva_salas` criado e visível
- [ ] Print 5 — Script SQL executado sem erros
- [ ] Print 6 — Resultado da consulta JOIN com os dados de exemplo
