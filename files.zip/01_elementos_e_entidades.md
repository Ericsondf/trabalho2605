# Meta 1 — Identificação de Elementos e Entidades

## Contexto do problema

Uma instituição possui salas de estudo que podem ser reservadas por alunos. Atualmente, as reservas são feitas por mensagens em aplicativos, gerando conflitos de horário, dificuldade de rastreamento e ausência de histórico.

O objetivo é modelar um banco de dados que registre salas, solicitantes e reservas, permitindo saber quem reservou qual sala, em qual data, em qual horário e qual é a situação da reserva.

---

## Elementos identificados no problema

| Elemento            | Tipo                  | Relevância                                                                 | Decisão              |
|---------------------|-----------------------|----------------------------------------------------------------------------|----------------------|
| Sala                | Objeto principal      | É o recurso que será reservado.                                            | Entidade             |
| Solicitante         | Ator                  | É a pessoa que realiza a reserva.                                          | Entidade             |
| Reserva             | Evento                | Registra a ocupação de uma sala por um solicitante em data/horário definidos. | Entidade          |
| Data da reserva     | Informação temporal   | Indica quando a sala será utilizada.                                       | Atributo de Reserva  |
| Horário de início   | Informação temporal   | Marca o início da ocupação da sala.                                        | Atributo de Reserva  |
| Horário de fim      | Informação temporal   | Marca o término da ocupação da sala.                                       | Atributo de Reserva  |
| Situação da reserva | Estado                | Indica se a reserva está ativa, cancelada ou concluída.                    | Atributo de Reserva  |
| Capacidade da sala  | Característica física | Ajuda a escolher a sala mais adequada para o grupo.                        | Atributo de Sala     |
| E-mail do solicitante | Contato             | Permite identificar ou contatar quem fez a reserva.                        | Atributo de Solicitante |

---

## Entidades definidas

### Entidade: `sala`

**Responsabilidade:** representar o espaço físico que pode ser reservado.

**Atributos:**

| Atributo     | Tipo        | Descrição                                         |
|--------------|-------------|---------------------------------------------------|
| id           | Inteiro (PK)| Identificador único da sala.                      |
| nome         | Texto       | Nome ou código de identificação da sala.          |
| capacidade   | Inteiro     | Número máximo de pessoas que a sala comporta.     |
| localizacao  | Texto       | Bloco, andar ou descrição do local.               |
| status       | Texto       | Indica se a sala está ativa ou desativada.        |

---

### Entidade: `solicitante`

**Responsabilidade:** representar a pessoa (aluno) que solicita uma reserva.

**Atributos:**

| Atributo  | Tipo        | Descrição                                        |
|-----------|-------------|--------------------------------------------------|
| id        | Inteiro (PK)| Identificador único do solicitante.              |
| nome      | Texto       | Nome completo do aluno.                          |
| matricula | Texto       | Número de matrícula institucional.               |
| email     | Texto       | E-mail de contato do aluno.                      |
| telefone  | Texto       | Telefone de contato (opcional).                  |

---

### Entidade: `reserva`

**Responsabilidade:** registrar o vínculo entre um solicitante, uma sala, uma data e um intervalo de horário.

**Atributos:**

| Atributo        | Tipo        | Descrição                                                         |
|-----------------|-------------|-------------------------------------------------------------------|
| id              | Inteiro (PK)| Identificador único da reserva.                                   |
| sala_id         | Inteiro (FK)| Referência à sala reservada.                                      |
| solicitante_id  | Inteiro (FK)| Referência ao solicitante.                                        |
| data            | Data        | Data em que a sala será utilizada.                                |
| hora_inicio     | Hora        | Horário de início da reserva.                                     |
| hora_fim        | Hora        | Horário de término da reserva.                                    |
| situacao        | Texto       | Estado atual: `ativa`, `cancelada` ou `concluida`.                |

---

## Recorte adotado

Esta primeira versão **não modela**:
- Autenticação ou controle de acesso.
- Pagamento ou taxas de uso.
- Aprovação por servidor ou administrador.
- Recorrência de reservas (ex.: toda segunda-feira).
- Múltiplos participantes por reserva.

O escopo fica limitado às três entidades centrais: **sala**, **solicitante** e **reserva**.
