# Meta 2 — Identificação de Relacionamentos

## Visão geral

Com as três entidades definidas na Meta 1 (`sala`, `solicitante` e `reserva`), o próximo passo é mapear como elas se conectam, definindo os relacionamentos, suas cardinalidades e as regras de negócio envolvidas.

---

## Relacionamentos identificados

### Relacionamento 1 — Solicitante **faz** Reserva

| Aspecto        | Descrição                                                                 |
|----------------|---------------------------------------------------------------------------|
| Entidades      | `solicitante` → `reserva`                                                 |
| Cardinalidade  | Um solicitante pode fazer **muitas** reservas. Cada reserva pertence a **um** solicitante. |
| Notação        | `solicitante (1) ────< reserva (N)`                                       |
| Obrigatoriedade | Uma reserva **deve** ter um solicitante. Um solicitante **pode** não ter reservas. |
| Implementação  | Chave estrangeira `solicitante_id` na tabela `reserva`, referenciando `solicitante(id)`. |

**Regra de negócio:** não é possível registrar uma reserva sem associá-la a um solicitante cadastrado.

---

### Relacionamento 2 — Sala **recebe** Reserva

| Aspecto        | Descrição                                                                 |
|----------------|---------------------------------------------------------------------------|
| Entidades      | `sala` → `reserva`                                                        |
| Cardinalidade  | Uma sala pode ter **muitas** reservas. Cada reserva está associada a **uma** sala. |
| Notação        | `sala (1) ────< reserva (N)`                                              |
| Obrigatoriedade | Uma reserva **deve** referenciar uma sala. Uma sala **pode** não ter reservas. |
| Implementação  | Chave estrangeira `sala_id` na tabela `reserva`, referenciando `sala(id)`. |

**Regra de negócio:** não é possível registrar uma reserva sem indicar qual sala será utilizada.

---

## Diagrama textual do modelo

```
solicitante                reserva                   sala
-----------                -------                   ----
id (PK) ──────────── solicitante_id (FK)     sala_id (FK) ──────── id (PK)
nome                       id (PK)                                  nome
matricula                  data                                     capacidade
email                      hora_inicio                              localizacao
telefone                   hora_fim                                 status
                           situacao
```

---

## Tabela resumo dos relacionamentos

| Relacionamento         | Cardinalidade | Tipo         | Chave estrangeira em |
|------------------------|---------------|--------------|----------------------|
| Solicitante faz Reserva | 1:N          | Identificador | `reserva.solicitante_id` |
| Sala recebe Reserva     | 1:N          | Identificador | `reserva.sala_id`        |

---

## Observações importantes

- A entidade `reserva` funciona como **tabela central (fato)** do modelo, concentrando as chaves estrangeiras.
- Não existe relacionamento direto entre `sala` e `solicitante`; a ligação sempre passa pela `reserva`.
- A restrição de **conflito de horário** (ex.: evitar que a mesma sala seja reservada duas vezes no mesmo horário) pode ser implementada via constraint ou validação na camada de aplicação. Neste caso simples, será documentada como regra de negócio pendente.

---

## Regras de negócio mapeadas

1. Um solicitante só pode ser excluído se não possuir reservas associadas (integridade referencial).
2. Uma sala só pode ser excluída se não possuir reservas associadas (integridade referencial).
3. A combinação `sala_id + data + hora_inicio + hora_fim` não deve ter sobreposição para reservas com situação `ativa`.
4. A `hora_fim` deve ser sempre maior que a `hora_inicio`.
