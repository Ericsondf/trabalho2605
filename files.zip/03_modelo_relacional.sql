-- ============================================================
-- Meta 3 — Modelo Relacional em PostgreSQL
-- Caso PBL: Reserva de Salas de Estudo
-- ============================================================

-- Garante que o script pode ser executado múltiplas vezes
-- sem erros de duplicidade (útil em ambiente de desenvolvimento).

-- ============================================================
-- 1. LIMPEZA (caso precise recriar)
-- ============================================================

DROP TABLE IF EXISTS reserva CASCADE;
DROP TABLE IF EXISTS solicitante CASCADE;
DROP TABLE IF EXISTS sala CASCADE;

-- ============================================================
-- 2. CRIAÇÃO DAS TABELAS
-- ============================================================

-- ------------------------------------------------------------
-- Tabela: sala
-- Representa os espaços físicos disponíveis para reserva.
-- ------------------------------------------------------------
CREATE TABLE sala (
    id          SERIAL          PRIMARY KEY,
    nome        VARCHAR(100)    NOT NULL UNIQUE,
    capacidade  INTEGER         NOT NULL CHECK (capacidade > 0),
    localizacao VARCHAR(200),
    status      VARCHAR(20)     NOT NULL DEFAULT 'ativa'
                                CHECK (status IN ('ativa', 'inativa'))
);

COMMENT ON TABLE  sala             IS 'Espaços físicos que podem ser reservados.';
COMMENT ON COLUMN sala.id          IS 'Identificador único da sala.';
COMMENT ON COLUMN sala.nome        IS 'Nome ou código da sala (único).';
COMMENT ON COLUMN sala.capacidade  IS 'Número máximo de ocupantes.';
COMMENT ON COLUMN sala.localizacao IS 'Bloco, andar ou descrição física do local.';
COMMENT ON COLUMN sala.status      IS 'ativa = disponível para reserva; inativa = fora de uso.';

-- ------------------------------------------------------------
-- Tabela: solicitante
-- Representa os alunos que podem realizar reservas.
-- ------------------------------------------------------------
CREATE TABLE solicitante (
    id        SERIAL          PRIMARY KEY,
    nome      VARCHAR(150)    NOT NULL,
    matricula VARCHAR(20)     NOT NULL UNIQUE,
    email     VARCHAR(150)    NOT NULL UNIQUE,
    telefone  VARCHAR(20)
);

COMMENT ON TABLE  solicitante           IS 'Alunos habilitados a realizar reservas.';
COMMENT ON COLUMN solicitante.id        IS 'Identificador único do solicitante.';
COMMENT ON COLUMN solicitante.nome      IS 'Nome completo do aluno.';
COMMENT ON COLUMN solicitante.matricula IS 'Número de matrícula institucional (único).';
COMMENT ON COLUMN solicitante.email     IS 'E-mail de contato (único).';
COMMENT ON COLUMN solicitante.telefone  IS 'Telefone de contato (opcional).';

-- ------------------------------------------------------------
-- Tabela: reserva
-- Registra o vínculo entre sala, solicitante, data e horário.
-- É a entidade central do modelo.
-- ------------------------------------------------------------
CREATE TABLE reserva (
    id              SERIAL      PRIMARY KEY,
    sala_id         INTEGER     NOT NULL
                                REFERENCES sala(id),
    solicitante_id  INTEGER     NOT NULL
                                REFERENCES solicitante(id),
    data            DATE        NOT NULL,
    hora_inicio     TIME        NOT NULL,
    hora_fim        TIME        NOT NULL,
    situacao        VARCHAR(20) NOT NULL DEFAULT 'ativa'
                                CHECK (situacao IN ('ativa', 'cancelada', 'concluida')),

    -- Garante que hora_fim é sempre maior que hora_inicio
    CONSTRAINT chk_horario_valido CHECK (hora_fim > hora_inicio)
);

COMMENT ON TABLE  reserva                IS 'Registro de ocupação de uma sala por um solicitante.';
COMMENT ON COLUMN reserva.id             IS 'Identificador único da reserva.';
COMMENT ON COLUMN reserva.sala_id        IS 'FK para a sala reservada.';
COMMENT ON COLUMN reserva.solicitante_id IS 'FK para o solicitante da reserva.';
COMMENT ON COLUMN reserva.data           IS 'Data em que a sala será utilizada.';
COMMENT ON COLUMN reserva.hora_inicio    IS 'Horário de início da reserva.';
COMMENT ON COLUMN reserva.hora_fim       IS 'Horário de término da reserva.';
COMMENT ON COLUMN reserva.situacao       IS 'Estado da reserva: ativa, cancelada ou concluida.';

-- ============================================================
-- 3. ÍNDICES
-- ============================================================

-- Acelera consultas de reservas por sala e data
CREATE INDEX idx_reserva_sala_data
    ON reserva (sala_id, data);

-- Acelera consultas de reservas por solicitante
CREATE INDEX idx_reserva_solicitante
    ON reserva (solicitante_id);

-- ============================================================
-- 4. DADOS DE EXEMPLO
-- ============================================================

-- Salas
INSERT INTO sala (nome, capacidade, localizacao) VALUES
    ('Sala A1', 10, 'Bloco A - 1º andar'),
    ('Sala B2', 6,  'Bloco B - 2º andar'),
    ('Sala C3', 20, 'Bloco C - Térreo');

-- Solicitantes
INSERT INTO solicitante (nome, matricula, email, telefone) VALUES
    ('Ana Souza',    '2024001', 'ana.souza@instituicao.edu.br',    '61999990001'),
    ('Bruno Lima',   '2024002', 'bruno.lima@instituicao.edu.br',   '61999990002'),
    ('Carla Mendes', '2024003', 'carla.mendes@instituicao.edu.br', NULL);

-- Reservas
INSERT INTO reserva (sala_id, solicitante_id, data, hora_inicio, hora_fim, situacao) VALUES
    (1, 1, '2025-08-04', '08:00', '10:00', 'ativa'),
    (2, 2, '2025-08-04', '14:00', '16:00', 'ativa'),
    (1, 3, '2025-08-05', '09:00', '11:00', 'cancelada'),
    (3, 1, '2025-08-06', '10:00', '12:00', 'ativa');

-- ============================================================
-- 5. CONSULTAS DE VERIFICAÇÃO
-- ============================================================

-- Lista todas as reservas com nomes de sala e solicitante
SELECT
    r.id                AS reserva_id,
    s.nome              AS sala,
    sl.nome             AS solicitante,
    r.data,
    r.hora_inicio,
    r.hora_fim,
    r.situacao
FROM reserva r
JOIN sala         s  ON s.id  = r.sala_id
JOIN solicitante  sl ON sl.id = r.solicitante_id
ORDER BY r.data, r.hora_inicio;
