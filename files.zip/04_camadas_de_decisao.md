# Meta 4 — Documentação de Decisões

## Objetivo

Este documento registra as escolhas feitas durante a modelagem, justificando o que virou entidade, o que virou atributo e o que foi deixado fora do escopo desta versão.

---

## 1. Decisões sobre entidades

### Por que `sala` é uma entidade?

A sala é o **recurso central** do sistema. Ela tem existência própria, independente de qualquer reserva: uma sala existe antes de ser reservada e continua existindo após a reserva ser concluída. Além disso, ela possui múltiplos atributos próprios (nome, capacidade, localização, status) e pode se relacionar com várias reservas ao longo do tempo. Essas características a qualificam como entidade.

### Por que `solicitante` é uma entidade?

O solicitante é um **ator com identidade própria** no sistema. Ele existe independentemente de fazer reservas, pode fazer múltiplas reservas ao longo do tempo e precisa ser identificado de forma única (por matrícula e e-mail). Tratá-lo como atributo da reserva criaria redundância de dados e inviabilizaria o histórico por pessoa.

### Por que `reserva` é uma entidade?

A reserva poderia ser interpretada apenas como o "relacionamento" entre sala e solicitante. Porém, ela **carrega atributos próprios relevantes** — data, hora de início, hora de fim e situação — que não pertencem nem à sala nem ao solicitante isoladamente. Quando um relacionamento possui atributos próprios e pode ser referenciado de forma independente, ele deve ser promovido a entidade. Esse padrão é chamado de **entidade associativa**.

---

## 2. Decisões sobre atributos

### `situacao` como texto com CHECK constraint

Optou-se por usar `VARCHAR` com uma constraint `CHECK` ao invés de criar uma tabela auxiliar de status. Para um caso simples com apenas três estados conhecidos (`ativa`, `cancelada`, `concluida`), essa abordagem é suficiente e evita complexidade desnecessária. Caso os estados se tornem dinâmicos, a evolução natural seria criar uma tabela `status_reserva`.

### `matricula` e `email` como UNIQUE

Ambos os campos foram declarados como `UNIQUE` para garantir que dois solicitantes não sejam cadastrados com os mesmos dados de identificação. Isso protege a integridade dos dados e impede duplicatas acidentais.

### `hora_inicio` e `hora_fim` como TIME separados

Separar os horários em dois campos permite calcular a duração da reserva, construir filtros de disponibilidade e aplicar a constraint `hora_fim > hora_inicio` diretamente no banco, sem depender da aplicação.

### `telefone` como opcional (nullable)

O telefone não é essencial para identificar o solicitante nem para viabilizar a reserva. Torná-lo opcional reduz a barreira de cadastro e reflete melhor a realidade do domínio.

---

## 3. O que ficou fora do escopo e por quê

| Elemento excluído             | Justificativa                                                                                   |
|-------------------------------|------------------------------------------------------------------------------------------------|
| Autenticação / login          | Foge do escopo de modelagem de dados. É uma responsabilidade da camada de aplicação.          |
| Aprovação por servidor        | Adicionaria uma entidade `aprovador` e um fluxo de aprovação, aumentando o escopo desnecessariamente. |
| Pagamento / taxa de uso       | Não há indicação no problema de que as reservas são pagas.                                     |
| Múltiplos participantes       | Exigiria uma tabela de associação adicional (`reserva_participante`). Não foi solicitado.      |
| Recorrência de reservas       | Reservas periódicas exigem lógica complexa de geração de ocorrências. Fora do escopo inicial. |
| Notificações / e-mail automático | Funcionalidade de aplicação, não de banco de dados.                                        |

---

## 4. Decisões de implementação no PostgreSQL

### Uso de `SERIAL` como chave primária

`SERIAL` gera automaticamente inteiros sequenciais, sendo uma solução simples e adequada para um sistema de escala pequena. Em cenários de alta concorrência ou sistemas distribuídos, `UUID` seria mais indicado.

### `ON DELETE` não declarado explicitamente

A integridade referencial padrão do PostgreSQL impede a exclusão de uma sala ou solicitante que possua reservas vinculadas, lançando um erro. Esta é a proteção mais segura para o escopo atual. Não foi definida a cláusula `ON DELETE CASCADE` intencionalmente, pois excluir em cascata dados de reserva é uma decisão de negócio que merece revisão antes de ser implementada.

### Índices criados

Foram criados dois índices adicionais:
- `idx_reserva_sala_data`: otimiza a consulta de disponibilidade de uma sala em uma data específica.
- `idx_reserva_solicitante`: otimiza a listagem do histórico de reservas de um solicitante.

---

## 5. Possíveis evoluções futuras

1. Adicionar tabela `status_reserva` para tornar os estados configuráveis.
2. Adicionar constraint de não sobreposição de horários para a mesma sala (via trigger ou regra de aplicação).
3. Incluir campo `motivo_cancelamento` em `reserva` para rastrear razões de cancelamento.
4. Criar tabela `participante_reserva` para suportar múltiplos participantes por reserva.
5. Adicionar campo `criado_em` (TIMESTAMP DEFAULT NOW()) em todas as tabelas para rastreabilidade.
